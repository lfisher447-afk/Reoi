# BingeBox Omega Roku v2 — Dev Tools

Two files. Drop them anywhere. Run them from Windows 11 Terminal.

---

## PowerShell Setup Script

```powershell
# Right-click → Run with PowerShell  OR  in Terminal:
.\BingeBox-Roku-Setup.ps1
```

**What it does:**
- Checks Node.js + npm + Python
- Auto-locates your BingeBox-Roku-v2 project folder
- Interactive menu:
  1. `npm install` (brighterscript + roku-deploy)
  2. `bsc` build → `out/.roku-deploy-staging/`
  3. Package `.zip` for Roku sideloading
  4. Deploy directly to a Roku device over your LAN
  5. Open Roku developer dashboard in browser
  6. Launch the Python dev assistant
  7. Full pipeline (install → build → package → deploy)

**If execution policy blocks it:**
```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

---

## Python Dev Assistant

```bash
# No external packages needed — pure stdlib
python bingebox_dev.py
# Or point it at your project:
python bingebox_dev.py C:\Users\You\Desktop\BingeBox-Roku-v2
```

**What it does:**
- **Inspect / lint** — checks all .bs↔.xml pairs, manifest, package.json
- **TMDB live tester** — validates your API key, searches, tests row endpoints
- **Server URL builder** — generates embed URLs for all 7 streaming servers
- **Package .zip** — creates a Roku-ready sideload zip (no Node.js required)
- **Edit manifest** — update title, version, splash colour, etc.
- **Config viewer** — dumps all servers + row endpoints from Config.bs

---

## Roku Sideload Steps

1. On your Roku: **Settings → System → Advanced system settings → Developer mode**
2. Note the IP shown on screen
3. Go to `http://<ROKU_IP>` in your browser
4. Username: `rokudev` / Password: whatever you set
5. Upload the `.zip` produced by either tool

---

## Requirements

| Tool | Needed for |
|------|-----------|
| Node.js 20+ | Build (bsc) + roku-deploy |
| Python 3.10+ | Python dev assistant |
| Roku in dev mode | Deployment |

Python assistant has **zero pip dependencies** — runs on stdlib only.
