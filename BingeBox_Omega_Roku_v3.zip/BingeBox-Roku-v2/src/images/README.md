# BingeBox Omega — Images

Place the following required Roku assets here:

| File                  | Size       | Purpose                  |
|-----------------------|------------|--------------------------|
| `icon_focus_hd.png`   | 540×405    | Home screen focused icon  |
| `icon_side_hd.png`    | 246×140    | Home screen side icon     |
| `splash_hd.png`       | 1920×1080  | Splash screen             |

Recommended: dark background (#06090f) with the BingeBox Ω wordmark in #E50914 red.
