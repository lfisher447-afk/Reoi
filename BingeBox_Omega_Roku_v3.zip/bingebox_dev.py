#!/usr/bin/env python3
"""
BingeBox Omega — Roku v2  |  Python Dev Assistant
Runs on Windows 11 (python bingebox_dev.py) or any platform.

Features:
  • TMDB API live tester (uses the key from Config.bs)
  • Project file inspector / linter (checks .bs + .xml pairs)
  • Streaming server URL builder & validator
  • Watch-history / registry JSON viewer
  • Roku sideload .zip packager (no Node needed)
  • Manifest editor
"""

import sys, os, json, re, zipfile, shutil, time, urllib.request, urllib.parse
from pathlib import Path
from datetime import datetime

# ─── ANSI colours (Windows 10+ natively supports them) ───────────────────────
R  = "\033[91m"  # red
G  = "\033[92m"  # green
Y  = "\033[93m"  # yellow
C  = "\033[96m"  # cyan
M  = "\033[95m"  # magenta
W  = "\033[97m"  # white
DG = "\033[90m"  # dark grey
RST = "\033[0m"

# Enable ANSI on Windows
if sys.platform == "win32":
    os.system("")

def clr(text, colour): return f"{colour}{text}{RST}"
def ok(msg):   print(f"  {clr('✓', G)} {msg}")
def err(msg):  print(f"  {clr('✗', R)} {msg}")
def warn(msg): print(f"  {clr('!', Y)} {msg}")
def step(msg): print(f"  {clr('>', C)} {msg}")
def info(msg): print(f"    {clr(msg, DG)}")
def sep():     print(f"  {clr('─' * 50, DG)}")

# ─── Extract values from Config.bs ───────────────────────────────────────────
TMDB_KEY_DEFAULT = "15d2ea6d0dc1d476efbca3eba2b9bbfb"

def read_config(project_root: Path) -> dict:
    cfg_path = project_root / "src" / "source" / "Services" / "Config.bs"
    result = {"tmdb_key": TMDB_KEY_DEFAULT, "servers": [], "rows": []}
    if not cfg_path.exists():
        warn(f"Config.bs not found at {cfg_path}")
        return result

    text = cfg_path.read_text(encoding="utf-8")

    # Extract TMDB key
    m = re.search(r'TMDB_KEY:\s*"([a-f0-9]+)"', text)
    if m:
        result["tmdb_key"] = m.group(1)

    # Extract server ids
    result["servers"] = re.findall(r'id:\s*"([^"]+)",\s*name:\s*"([^"]+)"', text)

    # Extract row endpoints
    result["rows"] = re.findall(r'endpoint:\s*"([^"]+)"', text)

    return result

# ─── TMDB helpers ─────────────────────────────────────────────────────────────
TMDB_BASE = "https://api.themoviedb.org/3"

def tmdb_fetch(endpoint: str, api_key: str) -> dict | None:
    sep_char = "&" if "?" in endpoint else "?"
    url = f"{TMDB_BASE}{endpoint}{sep_char}api_key={api_key}&language=en-US"
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            return json.loads(r.read().decode())
    except Exception as e:
        return None

def tmdb_search(query: str, api_key: str) -> list:
    data = tmdb_fetch(f"/search/multi?query={urllib.parse.quote(query)}", api_key)
    if data and "results" in data:
        return data["results"][:5]
    return []

# ─── Project inspector / linter ──────────────────────────────────────────────
def inspect_project(project_root: Path):
    print()
    step("Inspecting BingeBox Roku project...")
    sep()

    # Check manifest
    manifest = project_root / "src" / "manifest"
    if manifest.exists():
        ok("manifest found")
        for line in manifest.read_text().splitlines():
            info(line)
    else:
        err("manifest MISSING — Roku will reject the package!")

    sep()

    # Check components: every .xml should have a matching .bs
    comp_dir = project_root / "src" / "components"
    if comp_dir.exists():
        xml_files = list(comp_dir.glob("*.xml"))
        bs_files  = {f.stem for f in comp_dir.glob("*.bs")}
        ok(f"Components directory: {len(xml_files)} .xml files")
        for xf in sorted(xml_files):
            if xf.stem in bs_files:
                ok(f"  {xf.stem}.xml ↔ {xf.stem}.bs")
            else:
                warn(f"  {xf.stem}.xml has NO matching .bs script!")
    else:
        err("src/components/ directory missing!")

    sep()

    # Check source services
    svc_dir = project_root / "src" / "source" / "Services"
    utils_dir = project_root / "src" / "source" / "Utils"
    for d, label in [(svc_dir, "Services"), (utils_dir, "Utils")]:
        if d.exists():
            files = list(d.glob("*.bs"))
            ok(f"{label}/: {[f.name for f in files]}")
        else:
            err(f"src/source/{label}/ MISSING!")

    sep()

    # Check package.json devDependencies
    pkg = project_root / "package.json"
    if pkg.exists():
        data = json.loads(pkg.read_text())
        deps = data.get("devDependencies", {})
        ok(f"package.json devDependencies:")
        for k, v in deps.items():
            info(f"  {k}: {v}")
    else:
        err("package.json not found!")

    sep()

    # Scan .bs files for common issues
    step("Scanning .bs files for issues...")
    issues = []
    all_bs = list((project_root / "src").rglob("*.bs"))
    ok(f"Found {len(all_bs)} .bs files")
    for f in all_bs:
        text = f.read_text(encoding="utf-8", errors="replace")
        rel = f.relative_to(project_root)
        # Warn on sandbox usage (not applicable to Roku but flag anyway)
        if "sandbox=" in text.lower():
            issues.append(f"[sandbox attr] {rel}")
        # Check for leftover console.log
        if "console.log" in text:
            issues.append(f"[JS console.log in .bs!] {rel}")
        # Check for hardcoded localhost
        if "localhost" in text:
            warn(f"  Hardcoded 'localhost' in {rel}")

    if issues:
        err("Issues found:")
        for i in issues:
            info(f"  • {i}")
    else:
        ok("No issues found in .bs files")

    print()

# ─── Server URL builder ───────────────────────────────────────────────────────
SERVERS = [
    {"id": "vidlink",    "name": "VidLink Pro",  "movieBase": "https://vidlink.pro/movie/",              "tvBase": "https://vidlink.pro/tv/"},
    {"id": "vidsrcpro",  "name": "VidSrc PRO",   "movieBase": "https://vidsrc.pro/embed/movie/",         "tvBase": "https://vidsrc.pro/embed/tv/"},
    {"id": "videasy",    "name": "Videasy",       "movieBase": "https://player.videasy.net/movie/",       "tvBase": "https://player.videasy.net/tv/"},
    {"id": "vidsrccc",   "name": "VidSrc CC",     "movieBase": "https://vidsrc.cc/v2/embed/movie/",       "tvBase": "https://vidsrc.cc/v2/embed/tv/"},
    {"id": "autoembed",  "name": "AutoEmbed",     "movieBase": "https://player.autoembed.cc/embed/movie/","tvBase": "https://player.autoembed.cc/embed/tv/"},
    {"id": "2embed",     "name": "2Embed",        "movieBase": "https://www.2embed.cc/embed/",            "tvBase": "https://www.2embed.cc/embedtv/"},
    {"id": "vidsrcme",   "name": "VidSrc.ME",     "movieBase": "https://vidsrc.me/embed/movie?tmdb=",    "tvBase": "https://vidsrc.me/embed/tv?tmdb="},
]

def build_embed_url(tmdb_id: str, media_type: str, server: dict,
                    season=1, episode=1) -> str:
    if media_type == "movie":
        url = server["movieBase"] + tmdb_id
        if server["id"] == "vidlink":
            url += "?primaryColor=E50914&autoplay=true"
    else:
        url = server["tvBase"] + tmdb_id + f"/{season}/{episode}"
        if server["id"] == "vidsrcme":
            url = server["tvBase"] + tmdb_id + f"&season={season}&episode={episode}"
    return url

def server_url_builder():
    print()
    step("Streaming Server URL Builder")
    sep()
    tmdb_id    = input("  TMDB ID (e.g. 550 for Fight Club): ").strip()
    media_type = input("  Media type [movie/tv] (default: movie): ").strip() or "movie"

    if media_type == "tv":
        season  = input("  Season (default: 1): ").strip() or "1"
        episode = input("  Episode (default: 1): ").strip() or "1"
    else:
        season = episode = "1"

    print()
    ok(f"Generated URLs for TMDB ID {tmdb_id} ({media_type}):")
    sep()
    for srv in SERVERS:
        url = build_embed_url(tmdb_id, media_type, srv, season, episode)
        print(f"  {clr(srv['name'].ljust(14), C)} {url}")
    print()

# ─── TMDB live tester ─────────────────────────────────────────────────────────
def tmdb_tester(api_key: str):
    print()
    step("TMDB API Live Tester")
    info(f"Using API key: {api_key[:8]}...{api_key[-4:]}")
    sep()

    # Validate key first
    data = tmdb_fetch("/configuration", api_key)
    if data:
        ok("API key is VALID — connection successful")
    else:
        err("API key failed or no internet connection")
        return

    print()
    print("  Options:")
    print("  [1] Search for a movie/show")
    print("  [2] Test a home row endpoint")
    print("  [3] Get trending (week)")
    print("  [B] Back")
    print()
    choice = input("  Choose: ").strip().upper()

    if choice == "1":
        query = input("  Search query: ").strip()
        results = tmdb_search(query, api_key)
        if not results:
            warn("No results found.")
            return
        ok(f"Top {len(results)} results:")
        sep()
        for r in results:
            title = r.get("title") or r.get("name") or "?"
            mid   = r.get("id", "?")
            mtype = r.get("media_type", "?")
            year  = (r.get("release_date") or r.get("first_air_date") or "")[:4]
            rating = r.get("vote_average", 0)
            print(f"  {clr(str(mid).ljust(8), Y)} {clr(title.ljust(40), W)} {mtype.ljust(6)} {year}  ⭐{rating:.1f}")

    elif choice == "2":
        rows_sample = [
            "/trending/all/week",
            "/movie/popular",
            "/movie/now_playing",
            "/tv/top_rated",
            "/discover/movie?with_genres=28&sort_by=popularity.desc",
        ]
        print()
        for i, ep in enumerate(rows_sample):
            print(f"  [{i+1}] {ep}")
        idx = input("  Choose row (1-5): ").strip()
        try:
            endpoint = rows_sample[int(idx)-1]
        except:
            warn("Invalid choice"); return
        data = tmdb_fetch(endpoint, api_key)
        if not data or "results" not in data:
            err("Failed to fetch"); return
        ok(f"{len(data['results'])} items in '{endpoint}'")
        sep()
        for item in data["results"][:8]:
            title = item.get("title") or item.get("name") or "?"
            mid   = item.get("id", "?")
            rating = item.get("vote_average", 0)
            print(f"  ID:{clr(str(mid).ljust(8), Y)} {title.ljust(40)} ⭐{rating:.1f}")

    elif choice == "3":
        data = tmdb_fetch("/trending/all/week", api_key)
        if not data: err("Failed"); return
        ok("Trending this week:")
        sep()
        for i, item in enumerate(data.get("results", [])[:10], 1):
            title = item.get("title") or item.get("name") or "?"
            mtype = item.get("media_type", "?")
            print(f"  {clr(str(i).rjust(2), M)}. {clr(title.ljust(42), W)} [{mtype}]")

# ─── Zip packager (no Node.js required) ──────────────────────────────────────
def package_zip(project_root: Path):
    print()
    step("Packaging Roku .zip (Node-free)...")
    src_dir = project_root / "src"
    if not src_dir.exists():
        err(f"src/ directory not found in {project_root}")
        return

    ts = datetime.now().strftime("%Y%m%d-%H%M")
    zip_name = f"BingeBox-Omega-v3-{ts}.zip"
    zip_path = project_root / zip_name

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for file in src_dir.rglob("*"):
            if file.is_file():
                arcname = file.relative_to(src_dir)
                zf.write(file, arcname)
                info(f"  + {arcname}")

    size_kb = zip_path.stat().st_size // 1024
    ok(f"Package created: {zip_path} ({size_kb} KB)")
    info("Upload at: http://<ROKU_IP>  →  Development  →  Upload Channel")
    print()

# ─── Manifest editor ─────────────────────────────────────────────────────────
def edit_manifest(project_root: Path):
    manifest_path = project_root / "src" / "manifest"
    if not manifest_path.exists():
        err("manifest not found!"); return

    print()
    step("Current manifest:")
    sep()
    lines = manifest_path.read_text().splitlines()
    for i, line in enumerate(lines, 1):
        print(f"  {clr(str(i).rjust(2), DG)}  {line}")
    sep()

    print()
    print("  Edit a field (e.g. 'title=My App') or press Enter to cancel:")
    edit = input("  > ").strip()
    if not edit or "=" not in edit:
        warn("Cancelled."); return

    key, val = edit.split("=", 1)
    key = key.strip(); val = val.strip()

    new_lines = []
    replaced = False
    for line in lines:
        if line.startswith(key + "="):
            new_lines.append(f"{key}={val}")
            replaced = True
        else:
            new_lines.append(line)

    if not replaced:
        new_lines.append(f"{key}={val}")

    manifest_path.write_text("\n".join(new_lines) + "\n")
    ok(f"manifest updated: {key}={val}")

# ─── Main menu ────────────────────────────────────────────────────────────────
def find_project() -> Path | None:
    # Check arg first
    if len(sys.argv) > 1:
        p = Path(sys.argv[1])
        if (p / "package.json").exists():
            return p

    # Auto-discover
    candidates = [
        Path.cwd() / "BingeBox-Roku-v2",
        Path.home() / "Desktop" / "BingeBox-Roku-v2",
        Path.home() / "Downloads" / "BingeBox-Roku-v2",
        Path.home() / "Documents" / "BingeBox-Roku-v2",
        Path.cwd(),
    ]
    for c in candidates:
        if (c / "package.json").exists():
            return c

    return None

def main():
    # Enable colour on Windows
    if sys.platform == "win32":
        os.system("color")

    print()
    print(clr("  ╔══════════════════════════════════════════════╗", C))
    print(clr("  ║   BingeBox Omega — Python Dev Assistant      ║", C))
    print(clr("  ║   Roku v3.0  |  TMDB • Lint • Package       ║", C))
    print(clr("  ╚══════════════════════════════════════════════╝", C))
    print()

    project_root = find_project()
    if project_root:
        ok(f"Project root: {project_root}")
        cfg = read_config(project_root)
        api_key = cfg.get("tmdb_key", TMDB_KEY_DEFAULT)
    else:
        warn("Project not found. Some features disabled.")
        project_root = None
        api_key = TMDB_KEY_DEFAULT

    while True:
        print()
        print(clr("  ┌─ MENU ────────────────────────────────────┐", C))
        print(  "  │  [1] Inspect / lint project                │")
        print(  "  │  [2] TMDB API live tester                  │")
        print(  "  │  [3] Build streaming server URLs           │")
        print(  "  │  [4] Package .zip for Roku sideload        │")
        print(  "  │  [5] Edit manifest                         │")
        print(  "  │  [6] Show all servers & rows (from config) │")
        print(  "  │  [Q] Quit                                  │")
        print(clr("  └────────────────────────────────────────────┘", C))
        print()

        choice = input("  Choose: ").strip().upper()

        if choice == "1":
            if project_root:
                inspect_project(project_root)
            else:
                err("No project found.")
        elif choice == "2":
            tmdb_tester(api_key)
        elif choice == "3":
            server_url_builder()
        elif choice == "4":
            if project_root:
                package_zip(project_root)
            else:
                err("No project found.")
        elif choice == "5":
            if project_root:
                edit_manifest(project_root)
            else:
                err("No project found.")
        elif choice == "6":
            if project_root:
                cfg = read_config(project_root)
                print()
                ok(f"Servers ({len(cfg['servers'])}):")
                for sid, sname in cfg["servers"]:
                    print(f"    {clr(sid.ljust(12), Y)} {sname}")
                ok(f"Row endpoints ({len(cfg['rows'])}):")
                for ep in cfg["rows"]:
                    print(f"    {clr(ep, C)}")
            else:
                err("No project found.")
        elif choice == "Q":
            print()
            ok("Goodbye!")
            sys.exit(0)
        else:
            warn("Invalid option.")

if __name__ == "__main__":
    main()
