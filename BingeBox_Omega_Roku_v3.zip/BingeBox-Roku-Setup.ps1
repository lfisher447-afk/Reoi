# ============================================================
#  BingeBox Omega — Roku v2  |  Windows 11 Dev Setup Script
#  Run in PowerShell (Admin recommended for first-time setup)
#  Usage:  .\BingeBox-Roku-Setup.ps1
# ============================================================

$Host.UI.RawUI.WindowTitle = "BingeBox Omega — Roku Dev Setup"

$RED    = "Red"
$GREEN  = "Green"
$YELLOW = "Yellow"
$CYAN   = "Cyan"
$WHITE  = "White"
$MAGENTA = "Magenta"

function Banner {
    Clear-Host
    Write-Host ""
    Write-Host "  ██████╗ ██╗███╗   ██╗ ██████╗ ███████╗██████╗  ██████╗ ██╗  ██╗" -ForegroundColor Red
    Write-Host "  ██╔══██╗██║████╗  ██║██╔════╝ ██╔════╝██╔══██╗██╔═══██╗╚██╗██╔╝" -ForegroundColor Red
    Write-Host "  ██████╔╝██║██╔██╗ ██║██║  ███╗█████╗  ██████╔╝██║   ██║ ╚███╔╝ " -ForegroundColor Yellow
    Write-Host "  ██╔══██╗██║██║╚██╗██║██║   ██║██╔══╝  ██╔══██╗██║   ██║ ██╔██╗ " -ForegroundColor Yellow
    Write-Host "  ██████╔╝██║██║ ╚████║╚██████╔╝███████╗██████╔╝╚██████╔╝██╔╝ ██╗" -ForegroundColor Green
    Write-Host "  ╚═════╝ ╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚══════╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝" -ForegroundColor Green
    Write-Host ""
    Write-Host "  OMEGA ROKU v3.0  —  Windows 11 Developer Setup" -ForegroundColor Cyan
    Write-Host "  ─────────────────────────────────────────────────" -ForegroundColor DarkGray
    Write-Host ""
}

function Step($msg) { Write-Host "  [>] $msg" -ForegroundColor Cyan }
function Ok($msg)   { Write-Host "  [✓] $msg" -ForegroundColor Green }
function Warn($msg) { Write-Host "  [!] $msg" -ForegroundColor Yellow }
function Err($msg)  { Write-Host "  [✗] $msg" -ForegroundColor Red }
function Info($msg) { Write-Host "      $msg" -ForegroundColor DarkGray }

# ── 1. Node.js check ──────────────────────────────────────────────────────────
function Check-Node {
    Step "Checking Node.js..."
    $node = Get-Command node -ErrorAction SilentlyContinue
    if ($null -eq $node) {
        Warn "Node.js not found. Install from https://nodejs.org (LTS recommended)"
        $open = Read-Host "      Open browser to nodejs.org? [Y/n]"
        if ($open -ne "n") { Start-Process "https://nodejs.org" }
        Warn "Re-run this script after installing Node.js"
        exit 1
    }
    $ver = node --version
    Ok "Node.js found: $ver"

    # Check npm
    $npm = Get-Command npm -ErrorAction SilentlyContinue
    if ($null -eq $npm) {
        Err "npm not found (should come with Node.js)"
        exit 1
    }
    $npmVer = npm --version
    Ok "npm found: v$npmVer"
}

# ── 2. Python check ───────────────────────────────────────────────────────────
function Check-Python {
    Step "Checking Python 3..."
    $py = Get-Command python -ErrorAction SilentlyContinue
    if ($null -eq $py) {
        $py = Get-Command python3 -ErrorAction SilentlyContinue
    }
    if ($null -eq $py) {
        Warn "Python not found. Some dev tools require Python."
        Warn "Install from https://python.org or via: winget install Python.Python.3"
        return $false
    }
    $ver = python --version 2>&1
    Ok "Python found: $ver"
    return $true
}

# ── 3. Locate project ─────────────────────────────────────────────────────────
function Find-Project {
    Step "Locating BingeBox-Roku-v2 project..."

    $candidates = @(
        ".\BingeBox-Roku-v2",
        "$PSScriptRoot\BingeBox-Roku-v2",
        "$HOME\Desktop\BingeBox-Roku-v2",
        "$HOME\Downloads\BingeBox-Roku-v2",
        "$HOME\Documents\BingeBox-Roku-v2"
    )

    foreach ($c in $candidates) {
        if (Test-Path "$c\package.json") {
            Ok "Found project at: $c"
            return (Resolve-Path $c).Path
        }
    }

    Warn "Project not found in common locations."
    $manual = Read-Host "      Enter full path to BingeBox-Roku-v2 folder (or press Enter to skip)"
    if ($manual -ne "" -and (Test-Path "$manual\package.json")) {
        Ok "Using: $manual"
        return $manual
    }

    Warn "No project path set. npm tasks will be skipped."
    return $null
}

# ── 4. npm install ────────────────────────────────────────────────────────────
function Install-Deps($projectPath) {
    if ($null -eq $projectPath) { return }
    Step "Installing npm dependencies (brighterscript + roku-deploy)..."
    Push-Location $projectPath
    npm install 2>&1 | ForEach-Object { Info $_ }
    if ($LASTEXITCODE -ne 0) {
        Err "npm install failed!"
        Pop-Location
        return
    }
    Ok "Dependencies installed"
    Pop-Location
}

# ── 5. Build (bsc) ────────────────────────────────────────────────────────────
function Build-Project($projectPath) {
    if ($null -eq $projectPath) { return }
    Step "Building with BrighterScript (bsc)..."
    Push-Location $projectPath
    npm run build 2>&1 | ForEach-Object { Info $_ }
    if ($LASTEXITCODE -ne 0) {
        Err "Build failed! Check BrightScript syntax errors above."
        Pop-Location
        return
    }
    Ok "Build succeeded → out/.roku-deploy-staging/"
    Pop-Location
}

# ── 6. Package into .zip for Roku sideloading ────────────────────────────────
function Package-Zip($projectPath) {
    if ($null -eq $projectPath) { return }
    Step "Packaging .zip for Roku sideload..."

    $staging = Join-Path $projectPath "out\.roku-deploy-staging"
    if (-not (Test-Path $staging)) {
        Warn "Staging dir not found — run Build first."
        return
    }

    $zipName = "BingeBox-Omega-v3-$(Get-Date -Format 'yyyyMMdd-HHmm').zip"
    $zipPath = Join-Path $projectPath $zipName

    Compress-Archive -Path "$staging\*" -DestinationPath $zipPath -Force
    Ok "Package ready: $zipPath"
    Info "Upload via: http://<ROKU_IP> → Development → Upload"
}

# ── 7. Deploy to Roku (roku-deploy) ──────────────────────────────────────────
function Deploy-ToRoku($projectPath) {
    if ($null -eq $projectPath) { return }

    Write-Host ""
    Write-Host "  ┌─ ROKU DEVICE DEPLOY ──────────────────────────────────┐" -ForegroundColor Magenta
    Write-Host "  │  Make sure your Roku is in DEV MODE:                  │" -ForegroundColor Magenta
    Write-Host "  │  Settings → System → Advanced → Developer mode        │" -ForegroundColor Magenta
    Write-Host "  └───────────────────────────────────────────────────────┘" -ForegroundColor Magenta
    Write-Host ""

    $ip  = Read-Host "      Enter Roku device IP (e.g. 192.168.1.50) or press Enter to skip"
    if ($ip -eq "") { Warn "Skipping deploy."; return }

    $pwd = Read-Host "      Roku dev password (default: rokudev)" -AsSecureString
    $pwdPlain = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
        [Runtime.InteropServices.Marshal]::SecureStringToBSTR($pwd))
    if ($pwdPlain -eq "") { $pwdPlain = "rokudev" }

    # Write a temp roku-deploy config
    $cfg = @{
        host     = $ip
        password = $pwdPlain
        rootDir  = "out/.roku-deploy-staging"
    } | ConvertTo-Json

    $cfgPath = Join-Path $projectPath "rokudeploy-temp.json"
    $cfg | Set-Content $cfgPath

    Step "Deploying to $ip ..."
    Push-Location $projectPath
    npx roku-deploy --config $cfgPath 2>&1 | ForEach-Object { Info $_ }
    if ($LASTEXITCODE -eq 0) {
        Ok "Deployed successfully to Roku at $ip!"
    } else {
        Err "Deploy failed. Check IP, password, and developer mode."
    }
    Remove-Item $cfgPath -ErrorAction SilentlyContinue
    Pop-Location
}

# ── 8. Open Roku Dev Dashboard ────────────────────────────────────────────────
function Open-RokuDash {
    $ip = Read-Host "      Enter Roku IP to open dev dashboard (or Enter to skip)"
    if ($ip -ne "") {
        Start-Process "http://$ip"
        Ok "Opened http://$ip in browser"
    }
}

# ── 9. Python dev tools ───────────────────────────────────────────────────────
function Launch-PythonTool($projectPath) {
    if ($null -eq $projectPath) { return }
    Step "Launching Python dev assistant..."
    $pyScript = Join-Path $PSScriptRoot "bingebox_dev.py"
    if (Test-Path $pyScript) {
        python $pyScript $projectPath
    } else {
        Warn "bingebox_dev.py not found next to this script."
        Info "Run: python bingebox_dev.py <path-to-project>"
    }
}

# ── Main menu ─────────────────────────────────────────────────────────────────
function Show-Menu($projectPath) {
    while ($true) {
        Write-Host ""
        Write-Host "  ╔══════════════════════════════════════════╗" -ForegroundColor Cyan
        Write-Host "  ║        BINGEBOX OMEGA — DEV MENU         ║" -ForegroundColor Cyan
        Write-Host "  ╠══════════════════════════════════════════╣" -ForegroundColor Cyan
        Write-Host "  ║  [1] Install npm dependencies            ║"
        Write-Host "  ║  [2] Build (bsc compile)                 ║"
        Write-Host "  ║  [3] Package .zip for Roku sideload      ║"
        Write-Host "  ║  [4] Deploy to Roku device               ║"
        Write-Host "  ║  [5] Open Roku dev dashboard             ║"
        Write-Host "  ║  [6] Launch Python dev assistant         ║"
        Write-Host "  ║  [7] Full pipeline  (1→2→3→4)            ║" -ForegroundColor Yellow
        Write-Host "  ║  [Q] Quit                                ║"
        Write-Host "  ╚══════════════════════════════════════════╝" -ForegroundColor Cyan
        Write-Host ""
        if ($projectPath) {
            Write-Host "  Project: $projectPath" -ForegroundColor DarkGray
        } else {
            Write-Host "  Project: (not found)" -ForegroundColor DarkRed
        }
        Write-Host ""

        $choice = Read-Host "  Choose"
        switch ($choice.ToUpper()) {
            "1" { Install-Deps $projectPath }
            "2" { Build-Project $projectPath }
            "3" { Package-Zip $projectPath }
            "4" { Deploy-ToRoku $projectPath }
            "5" { Open-RokuDash }
            "6" { Launch-PythonTool $projectPath }
            "7" {
                Install-Deps $projectPath
                Build-Project $projectPath
                Package-Zip $projectPath
                Deploy-ToRoku $projectPath
            }
            "Q" { Write-Host "  Goodbye!" -ForegroundColor Green; exit 0 }
            default { Warn "Invalid option." }
        }
    }
}

# ── Entry point ───────────────────────────────────────────────────────────────
Banner
Check-Node
$hasPython = Check-Python
$projectPath = Find-Project
Write-Host ""
Ok "Environment check complete."
Show-Menu $projectPath
